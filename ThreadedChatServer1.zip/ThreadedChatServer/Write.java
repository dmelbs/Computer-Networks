import java.io.*;
import java.util.*;
import cs4hs11.rsalibrary.RSAMath;
import java.net.*;

public class Write implements Runnable {
    final DataInputStream input;
    final DataOutputStream output;
    private long E1;
    private long C1;
    long E;
    long D;
    long C;
    Scanner scan = new Scanner(System.in); // Initiate scanner
    int quit = 0;
     
    public Write( DataInputStream inputStream, DataOutputStream outputStream, long E, long C) {
        this.input = inputStream;
        this.output = outputStream;
        this.E1 = -1;
        this.C1 = -1;
        this.E = E;
        this.C = C;

    }

    public void setKeys(long E1, long C1){
        this.E1 = E1;
        this.C1 = C1;
    }

    @Override
    public void run() {
        try{
            output.writeLong(E);
            output.writeLong(C);
        }

        catch (IOException err) { // Catch exceptions and print
            err.printStackTrace();
        }
        while (true) {
            while(E1 == -1 || C1 == -1);
            String msg = scan.nextLine();
            
            try {
                Vector <Long> cryptMsg = new Vector<>();
                cryptMsg = Encryption.encrypt(msg, E1, C1);
                for(int i=0;i<cryptMsg.size();i++){
                    output.writeLong(cryptMsg.get(i));
                }
} 
            catch (IOException err) { // Catch exceptions and print
                err.printStackTrace();
            }
            }
        }
    }
