import cs4hs11.rsalibrary.RSAMath;
import java.io.*;
import java.util.*;
import cs4hs11.rsalibrary.RSAMath;
import java.net.*;

public class Encryption {

    public static Vector<Long> encrypt(String msg, long E, long C){

        Vector<Long> cryptMsg1 = new Vector<>();

        for(int i=0;i<msg.length();i++){
            long asciiX = (long) msg.charAt(i);
            long cryptMsgChar = RSAMath.endecrypt(asciiX, E, C);
            cryptMsg1.add(cryptMsgChar);
        }

        return cryptMsg1;
    }

    public static String decrypt( Vector<Long> cryptMsg1, long D, long C){

        String decryptMsg = "";

        for(int i = 0; i < cryptMsg1.size(); i++){ // Exit loop when reached message end
            long X = cryptMsg1.get(i);
            decryptMsg += (char)RSAMath.endecrypt(X, D, C);
        }

        return decryptMsg;
    }

    public static String decrypt1( long cryptMsg1, long D, long C){

        String decryptMsg = " ";


        decryptMsg += (char)RSAMath.endecrypt(cryptMsg1, D, C);

        return decryptMsg;
    }

    public static long[] generateKeys(){

        long A = 31;
        long B = 37;

        long C  = A*B;

        long M = RSAMath.totient(C);

        long E = RSAMath.coprime(M);

        long D = RSAMath.mod_inverse(E, M);

        long[] Keys = new long[3];

        Keys[0] = E;
        Keys[1] = D;
        Keys[2] = C;

        return Keys;
    }
}
