import java.io.*;
import java.util.*;
import cs4hs11.rsalibrary.RSAMath;
import java.net.*;

public class Recieve implements Runnable{
    long E1;
    long C1;
    long message;
    long E;
    long D;
    long C;
    private Write T;
    Socket socket;
    String totalMsg = "";


    public Recieve(Write T, Socket socket, long D) {
        this.socket = socket;
        this.T = T;
        this.D = D;
    }

        @Override
        public void run() {
            try{
                DataInputStream input = new DataInputStream(socket.getInputStream());
                E1 = input.readLong();
                C1 = input.readLong();
                T.setKeys(E1, C1);
                while (true) {
                    message = input.readLong();
                    if(message != 0){     
                        String message1 = Encryption.decrypt1(message, D, C1);
                        String st1 = message1.replaceAll("\\s+","");
                        totalMsg += st1;
                        if(st1.equals("0")){
                            StringTokenizer st2 = new StringTokenizer(totalMsg, "0");
                            String Msg = st2.nextToken();
                            System.out.println("Got: " + Msg);
                            totalMsg = "";
                        }
                        if(totalMsg.equals("exit")){
                            Server.close();
                            
                        }
                    }
    }
            }
            catch (IOException err) { // Catch exceptions and print
                err.printStackTrace();
            }
           
            }
        }


