import java.io.*;
import java.util.*;
import cs4hs11.rsalibrary.RSAMath;
import java.net.*;

public class Server {
    static Vector<ClientHandler> clientArray = new Vector<>(); // Store current clients
    static int clientCount = 0; // Client count

    public static void close(){
        System.exit(0);
    }
 
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9090); // Open server on port 9090
        Socket socket; // Socket declaration
        for(;;) { // Infinite loop to get client requests
            try{
                socket = serverSocket.accept(); // Accept incoming request
                System.out.println("New client request message : " + socket);
                 
                DataInputStream inputStream = new DataInputStream(socket.getInputStream()); // Input stream
                DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream()); // Output stream
                 
                System.out.println("Starting thread for client");
                ClientHandler client = new ClientHandler(socket,"client " + clientCount, inputStream, outputStream); // Declare client handler
                Thread clientThread = new Thread(client); // Start thread
                 
                System.out.println("Adding client to list of active clients");
                clientArray.add(client); // Add client to list
                clientThread.start(); // Start thread
                clientCount++; // Increment client counter
            }
            catch(IOException e) {
                e.printStackTrace(System.err);
              }
            
 
        }
    }
}

class ClientHandler implements Runnable {
    final DataInputStream inputStream;
    final DataOutputStream outputStream;
    String name;
    Socket socket;
    int ID;
    long[] keys = Encryption.generateKeys();
    long E = keys[0];
    long D = keys[1];
    long C = keys[2];
     
    public ClientHandler(Socket socket, String name, DataInputStream inputStream, DataOutputStream outputStream) {
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.name = name;
        this.socket = socket;
    }

    @Override
    public void run() {
        
        Write w = new Write(inputStream, outputStream, E, C);
        Thread write1 = new Thread(w);
        write1.start();
    
        Recieve R = new Recieve(w, socket, D);
        Thread recieve1 = new Thread(R);
        recieve1.start();
        
    }
}