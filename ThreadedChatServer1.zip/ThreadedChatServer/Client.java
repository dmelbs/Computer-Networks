import java.io.*;
import cs4hs11.rsalibrary.RSAMath;
import java.net.*;
import java.util.Scanner;
import java.util.Vector;

/**
 * The Client class represents a client in a chat program.
 */
public class Client 
{
    final static int Port = 9090;

    public static void main(String args[]) throws UnknownHostException, IOException {

        InetAddress ip = InetAddress.getByName("localhost"); // Get ip address of server
        Socket sock = new Socket(ip, Port); // Gain connection with the server via port
        System.out.println("Gained connection with server at port " + Port);
        DataInputStream input = new DataInputStream(sock.getInputStream()); // Input stream
        DataOutputStream output = new DataOutputStream(sock.getOutputStream()); // Output stream
        long[] keys = Encryption.generateKeys();
        long E = keys[0];
        long D = keys[1];
        long C = keys[2];

        Write w = new Write(input, output, E, C);
        Thread write1 = new Thread(w);
        write1.start();
        
        Recieve R = new Recieve(w, sock, D);
        Thread recieve1 = new Thread(R);
        recieve1.start();

    }
}
